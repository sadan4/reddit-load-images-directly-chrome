# Load Reddit Images Directly

Chrome extension to bypass reddits annoying page when viewing images.

From this:  
![](https://i.imgur.com/V1PFeHh.png)

To this:  
![](https://i.imgur.com/8gwbU5E.png)

---

Rewritten chrome version based on the firefox extension by [nopperl](https://github.com/nopperl/load-reddit-images-directly)
